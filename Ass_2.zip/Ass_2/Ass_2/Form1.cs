﻿/* ASSIGNMENT 2 GRP 15
Khush patel & Harsh Patel
Purpose: TO CREATE FORM VALIDATION FOR CAR APPOINTMENT BOOKING SYSTEM*/
using System;
using System.IO;
using System.Net.Mail;
using System.Windows.Forms;

namespace Ass_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Book Car Maintenance";
            this.Width = 600;
            this.Height = 400;

            // Initialize TextBoxes
            txtCustomerName = new TextBox { Location = new System.Drawing.Point(120, 20) };
            txtAddress = new TextBox { Location = new System.Drawing.Point(120, 50) };
            txtCity = new TextBox { Location = new System.Drawing.Point(120, 80) };
            txtProvince = new TextBox { Location = new System.Drawing.Point(120, 110) };
            txtPostalCode = new TextBox { Location = new System.Drawing.Point(120, 140) };
            txtHomePhone = new TextBox { Location = new System.Drawing.Point(120, 170) };
            txtCellPhone = new TextBox { Location = new System.Drawing.Point(120, 200) };
            txtEmail = new TextBox { Location = new System.Drawing.Point(120, 230) };
            txtMakeModel = new TextBox { Location = new System.Drawing.Point(420, 20) };
            txtYear = new TextBox { Location = new System.Drawing.Point(420, 50) };
            txtProblem = new TextBox { Location = new System.Drawing.Point(420, 80), Multiline = true, Height = 80 };

            // Initialize DateTimePicker
            dtpAppointmentDate = new DateTimePicker { Location = new System.Drawing.Point(420, 170), Format = DateTimePickerFormat.Short };

            // Initialize Buttons
            btnBookAppointment = new Button { Text = "Book appointment", Location = new System.Drawing.Point(120, 260) };
            btnReset = new Button { Text = "Reset", Location = new System.Drawing.Point(240, 260) };
            btnClose = new Button { Text = "Close", Location = new System.Drawing.Point(360, 260) };
            btnPrefill = new Button { Text = "Pre-fill", Location = new System.Drawing.Point(480, 260) };

            // Initialize Error Label
            lblError = new Label { ForeColor = System.Drawing.Color.Red, Location = new System.Drawing.Point(120, 290), Width = 400 };

            // Add Controls to Form
            this.Controls.Add(new Label { Text = "Customer name:", Location = new System.Drawing.Point(20, 20) });
            this.Controls.Add(txtCustomerName);
            this.Controls.Add(new Label { Text = "Address:", Location = new System.Drawing.Point(20, 50) });
            this.Controls.Add(txtAddress);
            this.Controls.Add(new Label { Text = "City:", Location = new System.Drawing.Point(20, 80) });
            this.Controls.Add(txtCity);
            this.Controls.Add(new Label { Text = "Province:", Location = new System.Drawing.Point(20, 110) });
            this.Controls.Add(txtProvince);
            this.Controls.Add(new Label { Text = "Postal code:", Location = new System.Drawing.Point(20, 140) });
            this.Controls.Add(txtPostalCode);
            this.Controls.Add(new Label { Text = "Home phone:", Location = new System.Drawing.Point(20, 170) });
            this.Controls.Add(txtHomePhone);
            this.Controls.Add(new Label { Text = "Cell phone:", Location = new System.Drawing.Point(20, 200) });
            this.Controls.Add(txtCellPhone);
            this.Controls.Add(new Label { Text = "Email:", Location = new System.Drawing.Point(20, 230) });
            this.Controls.Add(txtEmail);
            this.Controls.Add(new Label { Text = "Make & model:", Location = new System.Drawing.Point(320, 20) });
            this.Controls.Add(txtMakeModel);
            this.Controls.Add(new Label { Text = "Year:", Location = new System.Drawing.Point(320, 50) });
            this.Controls.Add(txtYear);
            this.Controls.Add(new Label { Text = "Appointment date:", Location = new System.Drawing.Point(320, 170) });
            this.Controls.Add(dtpAppointmentDate);
            this.Controls.Add(new Label { Text = "Problem:", Location = new System.Drawing.Point(320, 80) });
            this.Controls.Add(txtProblem);
            this.Controls.Add(btnBookAppointment);
            this.Controls.Add(btnReset);
            this.Controls.Add(btnClose);
            this.Controls.Add(btnPrefill);
            this.Controls.Add(lblError);

            // Event Handlers
            btnBookAppointment.Click += BtnBookAppointment_Click;
            btnReset.Click += BtnReset_Click;
            btnClose.Click += BtnClose_Click;
            btnPrefill.Click += BtnPrefill_Click;
        }

        private void BtnBookAppointment_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            txtCustomerName.Text = ValidationHelper.Capitalize(txtCustomerName.Text);
            txtAddress.Text = ValidationHelper.Capitalize(txtAddress.Text);
            txtCity.Text = ValidationHelper.Capitalize(txtCity.Text);
            txtMakeModel.Text = ValidationHelper.Capitalize(txtMakeModel.Text);
            txtProvince.Text = txtProvince.Text.ToUpper();
            txtPostalCode.Text = txtPostalCode.Text.ToUpper().Insert(3, " ");
            txtEmail.Text = txtEmail.Text.ToLower();

            if (!ValidateInputs(out string errorMessage))
            {
                lblError.Text = errorMessage;
                return;
            }

            string appointment = $"{txtCustomerName.Text}|{txtAddress.Text}|{txtCity.Text}|{txtProvince.Text}|{txtPostalCode.Text}|{txtHomePhone.Text}|{txtCellPhone.Text}|{txtEmail.Text}|{txtMakeModel.Text}|{txtYear.Text}|{dtpAppointmentDate.Value.ToShortDateString()}|{txtProblem.Text.Replace(Environment.NewLine, "~")}";
            File.AppendAllText("appointments.txt", appointment + Environment.NewLine);
            MessageBox.Show("Appointment booked successfully!");
            BtnReset_Click(sender, e);
        }

        private bool ValidateInputs(out string errorMessage)
        {
            errorMessage = "";
            bool isValid = true;

            if (string.IsNullOrWhiteSpace(txtCustomerName.Text))
            {
                errorMessage += "Customer name is required and cannot be just blanks.\n";
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                if (string.IsNullOrWhiteSpace(txtAddress.Text) ||
                    string.IsNullOrWhiteSpace(txtCity.Text) ||
                    string.IsNullOrWhiteSpace(txtProvince.Text) ||
                    string.IsNullOrWhiteSpace(txtPostalCode.Text))
                {
                    errorMessage += "If email is not provided, the postal information (address, city, province code, and postal code) is required.\n";
                    isValid = false;
                }
            }
            else
            {
                try
                {
                    MailAddress m = new MailAddress(txtEmail.Text);
                }
                catch (FormatException)
                {
                    errorMessage += "Email is not in a valid format.\n";
                    isValid = false;
                }
            }

            if (!string.IsNullOrWhiteSpace(txtProvince.Text) && !ValidationHelper.IsValidProvinceCode(txtProvince.Text))
            {
                errorMessage += "Province code must be exactly two letters and match a valid Canadian province or territory code.\n";
                isValid = false;
            }

            if (!string.IsNullOrWhiteSpace(txtPostalCode.Text) && !ValidationHelper.IsValidPostalCode(txtPostalCode.Text))
            {
                errorMessage += "Postal code must match the Canadian postal pattern 'A2A 2A2'.\n";
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(txtHomePhone.Text) && string.IsNullOrWhiteSpace(txtCellPhone.Text))
            {
                errorMessage += "At least one of home or cell phone numbers is required.\n";
                isValid = false;
            }
            else
            {
                if (!string.IsNullOrWhiteSpace(txtHomePhone.Text) && !ValidationHelper.IsValidPhoneNumber(txtHomePhone.Text))
                {
                    errorMessage += "Home phone number must fit the pattern '123-123-1234'.\n";
                    isValid = false;
                }
                if (!string.IsNullOrWhiteSpace(txtCellPhone.Text) && !ValidationHelper.IsValidPhoneNumber(txtCellPhone.Text))
                {
                    errorMessage += "Cell phone number must fit the pattern '123-123-1234'.\n";
                    isValid = false;
                }
            }

            if (string.IsNullOrWhiteSpace(txtMakeModel.Text))
            {
                errorMessage += "Make & model is required and cannot be just blanks.\n";
                isValid = false;
            }

            if (!string.IsNullOrWhiteSpace(txtYear.Text))
            {
                if (!int.TryParse(txtYear.Text, out int year) || year < 1886 || year > DateTime.Now.Year)
                {
                    errorMessage += "Year must be a number and must be between 1886 and the current year.\n";
                    isValid = false;
                }
            }

            return isValid;
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            txtCustomerName.Text = "";
            txtAddress.Text = "";
            txtCity.Text = "";
            txtProvince.Text = "";
            txtPostalCode.Text = "";
            txtHomePhone.Text = "";
            txtCellPhone.Text = "";
            txtEmail.Text = "";
            txtMakeModel.Text = "";
            txtYear.Text = "";
            txtProblem.Text = "";
            dtpAppointmentDate.Value = DateTime.Now;
            lblError.Text = "";
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnPrefill_Click(object sender, EventArgs e)
        {
            txtCustomerName.Text = "Khush Patel";
            txtAddress.Text = "123 Weber St";
            txtCity.Text = "Waterloo";
            txtProvince.Text = "ON";
            txtPostalCode.Text = "N2C 2H8";
            txtHomePhone.Text = "123-456-7890";
            txtCellPhone.Text = "099-999-9999";
            txtEmail.Text = "Khush.patel@example.com";
            txtMakeModel.Text = "Porsche Cayenne";
            txtYear.Text = "2015";
            txtProblem.Text = "Oil change\nTire rotation";
            dtpAppointmentDate.Value = DateTime.Now.AddDays(7);
        }
    }
}
