﻿/* ASSIGNMENT 2 GRP 15
Khush patel & Harsh Patel
Purpose: TO CREATE FORM VALIDATION FOR CAR APPOINTMENT BOOKING SYSTEM*/
public static class ValidationHelper
{
    public static string Capitalize(string input)
    {
        if (string.IsNullOrEmpty(input)) return string.Empty;
        
        input = input.Trim().ToLower();
        var words = input.Split(' ');
        for (int i = 0; i < words.Length; i++)
        {
            if (words[i].Length > 0)
            {
                words[i] = char.ToUpper(words[i][0]) + words[i].Substring(1);
            }
        }
        return string.Join(" ", words);
    }

    public static bool IsValidPostalCode(string postalCode)
    {
        if (string.IsNullOrWhiteSpace(postalCode)) return false;
        postalCode = postalCode.Replace(" ", "").ToUpper();
        if (postalCode.Length != 6) return false;

        var regex = new System.Text.RegularExpressions.Regex(@"^[A-Z]\d[A-Z]\d[A-Z]\d$");
        return regex.IsMatch(postalCode);
    }

    public static bool IsValidProvinceCode(string provinceCode)
    {
        if (string.IsNullOrWhiteSpace(provinceCode)) return false;
        var validCodes = new HashSet<string> { "AB", "BC", "MB", "NB", "NL", "NS", "NT", "NU", "ON", "PE", "QC", "SK", "YT" };
        return validCodes.Contains(provinceCode.ToUpper());
    }

    public static bool IsValidPhoneNumber(string phoneNumber)
    {
        if (string.IsNullOrWhiteSpace(phoneNumber)) return false;
        var regex = new System.Text.RegularExpressions.Regex(@"^\d{3}-\d{3}-\d{4}$");
        return regex.IsMatch(phoneNumber);
    }
}
