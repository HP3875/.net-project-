﻿/* ASSIGNMENT 2 GRP 15
Khush patel & Harsh Patel
Purpose: TO CREATE FORM VALIDATION FOR CAR APPOINTMENT BOOKING SYSTEM*/
namespace Ass_2
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtProvince;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.TextBox txtHomePhone;
        private System.Windows.Forms.TextBox txtCellPhone;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtMakeModel;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.TextBox txtProblem;
        private System.Windows.Forms.DateTimePicker dtpAppointmentDate;
        private System.Windows.Forms.Button btnBookAppointment;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnPrefill;
        private System.Windows.Forms.Label lblError;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtProvince = new System.Windows.Forms.TextBox();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.txtHomePhone = new System.Windows.Forms.TextBox();
            this.txtCellPhone = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtMakeModel = new System.Windows.Forms.TextBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.txtProblem = new System.Windows.Forms.TextBox();
            this.dtpAppointmentDate = new System.Windows.Forms.DateTimePicker();
            this.btnBookAppointment = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnPrefill = new System.Windows.Forms.Button();
            this.lblError = new System.Windows.Forms.Label();

            // Form1 properties
            this.Text = "Book Car Maintenance";
            this.Width = 600;
            this.Height = 400;

            // txtCustomerName
            this.txtCustomerName.Location = new System.Drawing.Point(120, 20);
            this.txtCustomerName.Size = new System.Drawing.Size(180, 22);

            // txtAddress
            this.txtAddress.Location = new System.Drawing.Point(120, 50);
            this.txtAddress.Size = new System.Drawing.Size(180, 22);

            // txtCity
            this.txtCity.Location = new System.Drawing.Point(120, 80);
            this.txtCity.Size = new System.Drawing.Size(180, 22);

            // txtProvince
            this.txtProvince.Location = new System.Drawing.Point(120, 110);
            this.txtProvince.Size = new System.Drawing.Size(180, 22);

            // txtPostalCode
            this.txtPostalCode.Location = new System.Drawing.Point(120, 140);
            this.txtPostalCode.Size = new System.Drawing.Size(180, 22);

            // txtHomePhone
            this.txtHomePhone.Location = new System.Drawing.Point(120, 170);
            this.txtHomePhone.Size = new System.Drawing.Size(180, 22);

            // txtCellPhone
            this.txtCellPhone.Location = new System.Drawing.Point(120, 200);
            this.txtCellPhone.Size = new System.Drawing.Size(180, 22);

            // txtEmail
            this.txtEmail.Location = new System.Drawing.Point(120, 230);
            this.txtEmail.Size = new System.Drawing.Size(180, 22);

            // txtMakeModel
            this.txtMakeModel.Location = new System.Drawing.Point(420, 20);
            this.txtMakeModel.Size = new System.Drawing.Size(180, 22);

            // txtYear
            this.txtYear.Location = new System.Drawing.Point(420, 50);
            this.txtYear.Size = new System.Drawing.Size(180, 22);

            // txtProblem
            this.txtProblem.Location = new System.Drawing.Point(420, 80);
            this.txtProblem.Size = new System.Drawing.Size(180, 80);
            this.txtProblem.Multiline = true;

            // dtpAppointmentDate
            this.dtpAppointmentDate.Location = new System.Drawing.Point(420, 170);
            this.dtpAppointmentDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpAppointmentDate.Size = new System.Drawing.Size(180, 22);

            // btnBookAppointment
            this.btnBookAppointment.Location = new System.Drawing.Point(120, 260);
            this.btnBookAppointment.Size = new System.Drawing.Size(100, 30);
            this.btnBookAppointment.Text = "Book appointment";
            this.btnBookAppointment.Click += new System.EventHandler(this.BtnBookAppointment_Click);

            // btnReset
            this.btnReset.Location = new System.Drawing.Point(240, 260);
            this.btnReset.Size = new System.Drawing.Size(100, 30);
            this.btnReset.Text = "Reset";
            this.btnReset.Click += new System.EventHandler(this.BtnReset_Click);

            // btnClose
            this.btnClose.Location = new System.Drawing.Point(360, 260);
            this.btnClose.Size = new System.Drawing.Size(100, 30);
            this.btnClose.Text = "Close";
            this.btnClose.Click += new System.EventHandler(this.BtnClose_Click);

            // btnPrefill
            this.btnPrefill.Location = new System.Drawing.Point(480, 260);
            this.btnPrefill.Size = new System.Drawing.Size(100, 30);
            this.btnPrefill.Text = "Pre-fill";
            this.btnPrefill.Click += new System.EventHandler(this.BtnPrefill_Click);

            // lblError
            this.lblError.Location = new System.Drawing.Point(120, 290);
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Size = new System.Drawing.Size(400, 40);

            // Labels
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Customer name:", Location = new System.Drawing.Point(20, 20), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Address:", Location = new System.Drawing.Point(20, 50), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "City:", Location = new System.Drawing.Point(20, 80), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Province:", Location = new System.Drawing.Point(20, 110), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Postal code:", Location = new System.Drawing.Point(20, 140), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Home phone:", Location = new System.Drawing.Point(20, 170), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Cell phone:", Location = new System.Drawing.Point(20, 200), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Email:", Location = new System.Drawing.Point(20, 230), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Make & model:", Location = new System.Drawing.Point(320, 20), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Year:", Location = new System.Drawing.Point(320, 50), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Appointment date:", Location = new System.Drawing.Point(320, 170), Size = new System.Drawing.Size(100, 20) });
            this.Controls.Add(new System.Windows.Forms.Label { Text = "Problem:", Location = new System.Drawing.Point(320, 80), Size = new System.Drawing.Size(100, 20) });

            // Add controls to Form
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtProvince);
            this.Controls.Add(this.txtPostalCode);
            this.Controls.Add(this.txtHomePhone);
            this.Controls.Add(this.txtCellPhone);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtMakeModel);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.txtProblem);
            this.Controls.Add(this.dtpAppointmentDate);
            this.Controls.Add(this.btnBookAppointment);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnPrefill);
            this.Controls.Add(this.lblError);
        }
    }
}
